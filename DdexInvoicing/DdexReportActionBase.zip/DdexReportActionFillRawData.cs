﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YouTubeInvoicingConsole
{
    class DdexReportActionFillRawData : DdexReportActionBase
    {
        private DdexReport report;
        private SqlConnection sqlConn;
        private int lastProcessedBlockId;

        Dictionary<string, BulkUploadToSql> bulkUploaders = new Dictionary<string, BulkUploadToSql>();
        HashSet<string> recordsToCorrect;
        
        public DdexReportActionFillRawData()
        {

        }

        private void RegisterBulkUploader(string tableName)
        {
           var bulkUploader = new BulkUploadToSql
                {
                    TableName = tableName,
                    sqlConn = sqlConn
                };
            bulkUploaders.Add(tableName, bulkUploader);
        }

        public override void Init(DdexReport report)
        {
            this.report = report;
            try
            {
                sqlConn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
                sqlConn.Open();
            }
            catch (Exception ex)
            {
                Logger.WriteLine(ex.Message);
            }

            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandText = @"DECLARE @lastBlockId int;
                        SELECT @lastBlockId = MAX(CAST(BlockId AS int)) FROM AS01_01 WHERE fileId = @DdexReportId;
                        DELETE FROM LI01_02 WHERE fileId = @DdexReportId and BlockId = @lastBlockId; 
                        DELETE FROM RU01_01 WHERE fileId = @DdexReportId and BlockId = @lastBlockId; 
                        DELETE FROM SU03_02 WHERE fileId = @DdexReportId and BlockId = @lastBlockId; 
                        DELETE FROM MW01_01 WHERE fileId = @DdexReportId and BlockId = @lastBlockId; 
                        DELETE FROM AS01_01 WHERE fileId = @DdexReportId and BlockId = @lastBlockId; 
                        SELECT @lastBlockId";
            sqlCmd.Parameters.Add(new SqlParameter("@DdexReportId", report.ddexReportId));
            sqlCmd.Connection = sqlConn;
            try
            {
                object lastProcessed = sqlCmd.ExecuteScalar();
                lastProcessedBlockId = lastProcessed == null ? 0 : int.Parse(lastProcessed.ToString());
            }
            catch (Exception ex)
            {
                Logger.WriteLine(ex.Message);
            }

            recordsToCorrect = new HashSet<string>();
            sqlCmd.CommandText = @"SELECT BlockId, RecordType, RecordIndex FROM DdexFileErrors WHERE DdexReportId = @DdexReportId";
            try
            {
                SqlDataReader reader = sqlCmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        recordsToCorrect.Add($"{reader.GetString(0)}-{reader.GetString(1)}-{reader.GetInt32(2)}");                    }
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Logger.WriteLine(ex.Message);
            }

            RegisterBulkUploader("HEAD");
            RegisterBulkUploader("FOOT");
            RegisterBulkUploader("SY02_02");
            RegisterBulkUploader("AS01_01");
            RegisterBulkUploader("MW01_01");
            RegisterBulkUploader("RU01_01");
            RegisterBulkUploader("SU03_02");
            RegisterBulkUploader("LI01_02");
        }

        public override int GetLastProcessedBlockId()
        {
            return lastProcessedBlockId;
        }

        private void AddParamsFromFields(SqlCommand sqlCmd, DdexRecordBase record)
        {
            for (int i = 1; i < record.Fields.Length; i++)
            {
                sqlCmd.Parameters.Add(new SqlParameter($"@{i}", record.ConvertField(i)));
                sqlCmd.CommandText += $", @{i}";
            }
            sqlCmd.CommandText += "); SELECT SCOPE_IDENTITY();";
        }

        private void InsertRecord(DdexRecordBase record, string tableName, bool isBlockRecord)
        {
            try
            {
                BulkUploadToSql bulkUploader = bulkUploaders[tableName];
                var data = new List<object>();
                if (isBlockRecord)
                    data.Add(null);
                data.Add(report.ddexReportId);
                for (int i = 1; i < record.Fields.Length; i++)
                {
                    data.Add(record.ConvertField(i));
                }
                bulkUploader.AddData(data);
            }
            catch (Exception ex)
            {
                Logger.WriteLine($"Error in table {tableName}, {ex.Message}");
                Logger.WriteLine($"   Wrong format of record");
                record.Dump(record.Fields);
             }
        }

        public override void ProcessHead(HEADRecord record)
        {
            InsertRecord(record, "HEAD", false);
        }

        public override void ProcessFoot(FOOTRecord record)
        {
            InsertRecord(record, "FOOT", false);
            foreach (var bulkUploader in bulkUploaders.Values)
                bulkUploader.Flush();
        }

        public override void ProcessSY(SYRecord record)
        {
            InsertRecord(record, "SY02_02", false);
        }

        public override void ProcessBlock(DdexReportBlock block)
        {
            try
            {
                InsertRecord(block.asRecord, "AS01_01", false);
                foreach (var mwRecord in block.asRecord.mwRecords)
                {
                    if (mwRecord.liRecords.Count == 0 /*|| mwRecord.liRecords[0].RightSharePercent.Equals("100.0000")*/)
                        return;
                    int destinationIndex = mwRecord.Fields.Length;
                    int sourceIndex = 2;
                    Array.Resize(ref mwRecord.fields, mwRecord.Fields.Length + mwRecord.liRecords[0].Fields.Length - sourceIndex);
                    Array.Copy(mwRecord.liRecords[0].fields, sourceIndex, mwRecord.fields, destinationIndex, mwRecord.liRecords[0].fields.Length - sourceIndex);
                    InsertRecord(mwRecord, "MW01_01", true);
                    foreach (var suRecord in mwRecord.suRecords)
                    {
                        InsertRecord(suRecord, "SU03_02", true);
                    }
                    foreach (var ruRecord in mwRecord.ruRecords)
                    {
                        InsertRecord(ruRecord, "RU01_01", true);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLine(ex.Message);
            }
         }
    }
}
