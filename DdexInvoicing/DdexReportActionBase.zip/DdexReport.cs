﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YouTubeInvoicingConsole
{

    class DdexReport
    {
        List<HEADRecord> headRecords = new List<HEADRecord>();
        List<FOOTRecord> footRecords = new List<FOOTRecord>();
        Dictionary<string, SYRecord> syRecords = new Dictionary<string, SYRecord>();
        public HashSet<string> recordsToCorrect;


        public float usagesFromSU = 0;
        public float usagesFromRU = 0;

        // Statistics
        public DdexStatistics statistics = new DdexStatistics();
        public int maxCountAS = 0;
        public int maxCountMW = 0;
        public int maxCountRU = 0;
        public int maxCountSU = 0;
        public int maxCountLI = 0;

        public bool missingRU = false;
        public bool missingSU = false;
        public bool missingLI = false;

        // Settings
        public string filesPath;
        public List<string> fileNames = new List<string>();
        public int ddexReportId;
        public Guid invoiceId;
        public string connectString;

        //
        private int lastProcessedBlockId = 0;

        public void ProcessFiles(DdexReportActionBase action)
        {
            Logger.WriteLine($"Processing started");

            SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
            try
            {
                sqlConn.Open();
            }
            catch (Exception ex)
            {
                Logger.WriteLine(ex.Message);
            }

            recordsToCorrect = new HashSet<string>();
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.Parameters.Add(new SqlParameter("@DdexReportId", ddexReportId));
            sqlCmd.Connection = sqlConn;
            sqlCmd.CommandText = @"SELECT BlockId, RecordType, RecordIndex FROM DdexFileErrors WHERE DdexReportId = @DdexReportId";
            try
            {
                SqlDataReader reader = sqlCmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        recordsToCorrect.Add($"{reader.GetString(0)}-{reader.GetString(1)}");
                    }
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Logger.WriteLine(ex.Message);
            }

            action.Init(this);
            lastProcessedBlockId = action.GetLastProcessedBlockId();
            try
            {
                foreach (var fileName in fileNames)
                {
                    ProcessFile(filesPath + fileName, action);
                }
            }
            catch(Exception ex)
            {
                Logger.WriteLine(ex.Message);
                Logger.WriteLine($"Processing interrupted");
            }
            Logger.WriteLine($"Processing completed");
        }

        public void ProcessFile(string fileName, DdexReportActionBase action)
        {
            Logger.WriteLine($"Processing File {fileName}");
            syRecords = new Dictionary<string, SYRecord>();
            FileStream fileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            using (var streamReader = new StreamReader(fileStream, Encoding.UTF8))
            {
                while (!streamReader.EndOfStream)
                {
                    var line = streamReader.ReadLine();

                    if (line[0] != '#')
                    {
                        var fields = line.Split('\t');
                        var recordType = fields[0];
                        if(recordType.Equals("HEAD"))
                        {
                            Logger.WriteLine($"Processing record {fields[0]}");
                            HEADRecord record = new HEADRecord();
                            record.Fields = fields;
                            if (record.Fields != null)
                            {
                                headRecords.Add(record);
                                action.ProcessHead(record);
                            }
                        }
                        else if (recordType.Equals("SY02.02"))
                        {
                            Logger.WriteLine($"Processing record {fields[0]}");
                            SYRecord record = new SYRecord();
                            record.Fields = fields;
                            if (record.Fields != null)
                            {
                                string summaryRecordId = fields[(int)SYRecord.FieldIds.SummaryRecordId];
                                if (!syRecords.ContainsKey(summaryRecordId))
                                    syRecords.Add(summaryRecordId, record);
                                action.ProcessSY(record);
                            }
                        }
                        else
                        {
                            while (true)
                            {
                                var block = new DdexReportBlock(this);
                                block.Init(streamReader, ref line);
                                if (int.Parse(block.asRecord.BlockId) < lastProcessedBlockId)
                                    continue;
                                if (!block.Process(action, streamReader, ref line))
                                    break;
                            }
                            // Process foot
                            Logger.WriteLine($"Processing FOOT");
                            FOOTRecord record = new FOOTRecord();
                            record.Fields = line.Split('\t');
                            if (record.Fields != null)
                            {
                                footRecords.Add(record);
                                action.ProcessFoot(record);
                            }
                        }
                    }
                }
            }
            fileStream.Close();
        }

        public string GetAllocatedNetRevenue(string summaryRecordId)
        {
            return syRecords[summaryRecordId].Fields[(int)SYRecord.FieldIds.AllocatedNetRevenue];
        }

        public void AddPercentFromMS(string summaryRecordId, float percent)
        {
            syRecords[summaryRecordId].TotalSumPercentFromMW += percent;
        }

        public SYRecord GetSummaryRecord(string summaryRecordId)
        {
            return syRecords[summaryRecordId];
        }
    }
}
