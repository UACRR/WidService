﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YouTubeInvoicingConsole
{
    class CcidInvoice
    {
        class ColInfo
        {
            public string Name;
            public int Size;
        }

        private const string invoiceId = "491EDBF7-85CC-4115-9588-9787401836AB";

        private readonly ColInfo[] colInfo = new ColInfo[] {
            new ColInfo { Name ="Id", Size = 100}
            , new ColInfo { Name ="SequenceNumber", Size = 100}
            , new ColInfo { Name ="CcidInvoiceId", Size = 100}
            , new ColInfo { Name ="TRANSACTION_TYPE", Size = 3}
            , new ColInfo { Name ="REF_ID", Size = 20}
            , new ColInfo { Name ="CORRECTION_REFERENCE", Size = 20}
            , new ColInfo { Name ="SALES_TRANSACTION_ID", Size = 20}
            , new ColInfo { Name ="TRADING_BRAND", Size = 18}
            , new ColInfo { Name ="RELEASE_ID", Size = 60}
            , new ColInfo { Name ="RESOURCE_ID", Size = 60}
            , new ColInfo { Name ="ISRC", Size = 12}
            , new ColInfo { Name ="ISWC", Size = 11}
            , new ColInfo { Name ="WORKCODE", Size = 39}
            , new ColInfo { Name ="WORK_TITLE", Size = 60}
            , new ColInfo { Name ="SERVICE_TYPE", Size = 10}
            , new ColInfo { Name ="USE_TYPE", Size = 10}
            , new ColInfo { Name ="USE_QUANTITY", Size = 8}
            , new ColInfo { Name ="APPLIED_TARIFF", Size = 10}
            , new ColInfo { Name ="ROYALTY_TYPE", Size = 2}
            , new ColInfo { Name ="PRICE_BASIS", Size = 7}
            , new ColInfo { Name ="ORIGINAL_PRICE_BASIS", Size = 7}
            , new ColInfo { Name ="ROYALTY", Size = 9}
            , new ColInfo { Name ="MUSIC_SHARE", Size = 5}
            , new ColInfo { Name ="RESTRICTIONS", Size = 10}
            , new ColInfo { Name ="FST_LICENSE", Size = 1}
            , new ColInfo { Name ="CLAIM_LICENSOR_COMBINED", Size = 5}
            , new ColInfo { Name ="CLAIM_PAI_COMBINED", Size = 5}
            , new ColInfo { Name ="CLAIM_UNMATCHED_COMBINED", Size = 5}
            , new ColInfo { Name ="CLAIM_PD_COMBINED", Size = 5}
            , new ColInfo { Name ="CLAIM_NOT_COLLECTED_COMBINED", Size = 5}
            , new ColInfo { Name ="AMOUNT_INVOICED_TOTAL", Size = 13}
            , new ColInfo { Name ="CLAIM_LICENSOR_MECH", Size = 5}
            , new ColInfo { Name ="CLAIM_LICENSOR_PERF", Size = 5}
            , new ColInfo { Name ="AMOUNT_LICENSOR_MECH", Size = 13}
            , new ColInfo { Name ="AMOUNT_LICENSOR_PERF", Size = 13}
            , new ColInfo { Name ="AMOUNT_PAI_MECH", Size = 13}
            , new ColInfo { Name ="AMOUNT_PAI_PERF", Size = 13}
            , new ColInfo { Name ="AMOUNT_PD_MECH", Size = 13}
            , new ColInfo { Name ="AMOUNT_PD_PERF", Size = 13}
            , new ColInfo { Name ="AMOUNT_NOT_COLLECTED_MECH", Size = 13}
            , new ColInfo { Name ="AMOUNT_NOT_COLLECTED_PERF", Size = 13}
            , new ColInfo { Name ="AMOUNT_UNMATCHED_MECH", Size = 13}
            , new ColInfo { Name ="AMOUNT_UNMATCHED_PERF", Size = 13}
            , new ColInfo { Name ="CLAIM_PAI_MECH", Size = 5}
            , new ColInfo { Name ="CLAIM_PAI_PERF", Size = 5}
            , new ColInfo { Name ="CLAIM_PD_MECH", Size = 5}
            , new ColInfo { Name ="CLAIM_PD_PERF", Size = 5}
            , new ColInfo { Name ="CLAIM_NOT_COLLECTED_MECH", Size = 5}
            , new ColInfo { Name ="CLAIM_NOT_COLLECTEDR_PERF", Size = 5}
            , new ColInfo { Name ="CLAIM_UNMATCHED_MECH", Size = 5}
            , new ColInfo { Name ="CLAIM_UNMATCHED_PERF", Size = 5}
        };

        #region sql
        const string sql = @"INSERT INTO CcidInvoiceDetailRecord (
              Id
            , SequenceNumber
            , CcidInvoiceId 
            , TRANSACTION_TYPE 
            , REF_ID 
            , CORRECTION_REFERENCE 
            , SALES_TRANSACTION_ID
            , TRADING_BRAND
            , RELEASE_ID
            , RESOURCE_ID
            , ISRC
            , ISWC
            , WORKCODE 
            , WORK_TITLE
            , SERVICE_TYPE
            , USE_TYPE
            , USE_QUANTITY
            , APPLIED_TARIFF
            , ROYALTY_TYPE
            , PRICE_BASIS
            , ORIGINAL_PRICE_BASIS
            , ROYALTY
            , MUSIC_SHARE
            , RESTRICTIONS
            , FST_LICENSE
            , CLAIM_LICENSOR_COMBINED
            , CLAIM_PAI_COMBINED
            , CLAIM_UNMATCHED_COMBINED
            , CLAIM_PD_COMBINED
            , CLAIM_NOT_COLLECTED_COMBINED
            , AMOUNT_INVOICED_TOTAL
            , CLAIM_LICENSOR_MECH
            , CLAIM_LICENSOR_PERF
            , AMOUNT_LICENSOR_MECH
            , AMOUNT_LICENSOR_PERF
            , AMOUNT_PAI_MECH
            , AMOUNT_PAI_PERF
            , AMOUNT_PD_MECH
            , AMOUNT_PD_PERF
            , AMOUNT_NOT_COLLECTED_MECH
            , AMOUNT_NOT_COLLECTED_PERF
            , AMOUNT_UNMATCHED_MECH
            , AMOUNT_UNMATCHED_PERF
            , CLAIM_PAI_MECH
            , CLAIM_PAI_PERF
            , CLAIM_PD_MECH
            , CLAIM_PD_PERF
            , CLAIM_NOT_COLLECTED_MECH
            , CLAIM_NOT_COLLECTEDR_PERF
            , CLAIM_UNMATCHED_MECH
            , CLAIM_UNMATCHED_PERF
            , SourceBlockId
            , SourceMusicWorkIndex
            , RightType
            ) VALUES (@Id
            , @SequenceNumber
            , @CcidInvoiceId 
            , @TRANSACTION_TYPE 
            , @REF_ID 
            , @CORRECTION_REFERENCE 
            , @SALES_TRANSACTION_ID
            , @TRADING_BRAND
            , @RELEASE_ID
            , @RESOURCE_ID
            , @ISRC
            , @ISWC
            , @WORKCODE 
            , @WORK_TITLE
            , @SERVICE_TYPE
            , @USE_TYPE
            , @USE_QUANTITY
            , @APPLIED_TARIFF
            , @ROYALTY_TYPE
            , @PRICE_BASIS
            , @ORIGINAL_PRICE_BASIS
            , @ROYALTY
            , @MUSIC_SHARE
            , @RESTRICTIONS
            , @FST_LICENSE
            , @CLAIM_LICENSOR_COMBINED
            , @CLAIM_PAI_COMBINED
            , @CLAIM_UNMATCHED_COMBINED
            , @CLAIM_PD_COMBINED
            , @CLAIM_NOT_COLLECTED_COMBINED
            , @AMOUNT_INVOICED_TOTAL
            , @CLAIM_LICENSOR_MECH
            , @CLAIM_LICENSOR_PERF
            , @AMOUNT_LICENSOR_MECH
            , @AMOUNT_LICENSOR_PERF
            , @AMOUNT_PAI_MECH
            , @AMOUNT_PAI_PERF
            , @AMOUNT_PD_MECH
            , @AMOUNT_PD_PERF
            , @AMOUNT_NOT_COLLECTED_MECH
            , @AMOUNT_NOT_COLLECTED_PERF
            , @AMOUNT_UNMATCHED_MECH
            , @AMOUNT_UNMATCHED_PERF
            , @CLAIM_PAI_MECH
            , @CLAIM_PAI_PERF
            , @CLAIM_PD_MECH
            , @CLAIM_PD_PERF
            , @CLAIM_NOT_COLLECTED_MECH
            , @CLAIM_NOT_COLLECTEDR_PERF
            , @CLAIM_UNMATCHED_MECH
            , @CLAIM_UNMATCHED_PERF
            , @SourceBlockId
            , @SourceMusicWorkIndex
            , @RightType
            )";
        #endregion sql

        private SqlConnection sqlConn;
        public void Init(string connectString)
        {
            sqlConn = new SqlConnection(connectString);
            sqlConn.Open();
        }

        private void CheckSizes(SqlParameterCollection sqlParams)
        {
            for(int i = 3; i < sqlParams.Count - 3; i++)
            {
                int size = ((string)sqlParams[i].Value).Length;
                if(size > colInfo[i].Size && !colInfo[i].Name.Equals("WORK_TITLE"))
                {
                    Logger.WriteLine($"{colInfo[i].Name} - data size ({size}) exceeded max size ({colInfo[i].Size})");
                }
             }
        }

        public void InsertMusicWorks(DdexReportBlock block)
        {
            Dictionary<string, MWRecord> recordsWithISWC = new Dictionary<string, MWRecord>();
            foreach (var mwRecord in block.asRecord.mwRecords)
            {
                foreach (var suRecord in mwRecord.suRecords)
                {
                    if(suRecord.SummaryRecordId.Equals("11"))
                    {
                        float usages = float.Parse(suRecord.Usages, NumberStyles.Any, CultureInfo.GetCultureInfo("en-US"));
                        block.report.usagesFromSU += usages;
                    }
                }
                foreach (var ruRecord in mwRecord.ruRecords)
                {
                    if (ruRecord.SummaryRecordId.Equals("11") && !string.IsNullOrEmpty(ruRecord.Usages.Trim()))
                    {
                        string[] usages = ruRecord.Usages.Split('|');
                        foreach(var usage in usages)
                        {
                            float floatUsage = float.Parse(usage, NumberStyles.Any, CultureInfo.GetCultureInfo("en-US"));
                            block.report.usagesFromRU += floatUsage;
                        }
                        
                    }
                }

                if (!string.IsNullOrEmpty(mwRecord.ISWC.Trim())&& !recordsWithISWC.ContainsKey(mwRecord.ISWC))
                    recordsWithISWC.Add(mwRecord.ISWC, mwRecord);
            };

            foreach (var mwRecord in block.asRecord.mwRecords)
            {
                if (recordsWithISWC.ContainsKey(mwRecord.ISWC))
                {
                    var mwRecordWithISWC = recordsWithISWC[mwRecord.ISWC];
                    if(mwRecordWithISWC.Title.Equals(mwRecord.Title, StringComparison.OrdinalIgnoreCase))
                        mwRecord.ISWC = mwRecordWithISWC.ISWC;
                }
            };

            List<MWRecord> targetRecords = new List<MWRecord>();
            Dictionary<string, int> processedISWCs = new Dictionary<string, int>();
            foreach (var mwRecord in block.asRecord.mwRecords)
            {
                if (string.IsNullOrEmpty(mwRecord.ISWC))
                    continue;
                if (!processedISWCs.ContainsKey(mwRecord.ISWC) && !string.IsNullOrEmpty(mwRecord.ComposerAuthor.Trim()))
                {
                    targetRecords.Add(mwRecord);
                    processedISWCs.Add(mwRecord.ISWC, 0);
                }
            };

            Dictionary<string, int> processedTitles = new Dictionary<string, int>();
            foreach (var mwRecord in block.asRecord.mwRecords)
            {
                if (!string.IsNullOrEmpty(mwRecord.ISWC))
                    continue;
                if (!processedTitles.ContainsKey(mwRecord.Title) && !string.IsNullOrEmpty(mwRecord.ComposerAuthor.Trim()))
                {
                    targetRecords.Add(mwRecord);
                    processedTitles.Add(mwRecord.Title, 0);
                }
            };

            foreach (var mwRecord in targetRecords)
                InsertMusicWork(block.report.ddexReportId, block.asRecord, mwRecord);
        }

        public void InsertMusicWork(int ddexReportId, ASRecord asRecord, MWRecord mwRecord)
        {
            SqlCommand sqlCmd = new SqlCommand();

            Guid mwId = Guid.NewGuid();

            sqlCmd.Parameters.Add(new SqlParameter("@Id", mwId));
            sqlCmd.Parameters.Add(new SqlParameter("@DdexReportId", ddexReportId));
            sqlCmd.Parameters.Add(new SqlParameter("@BlockId", mwRecord.BlockId));

            sqlCmd.Parameters.Add(new SqlParameter("@ISRC", asRecord.ISRC.Trim()));
            sqlCmd.Parameters.Add(new SqlParameter("@ResourceTitle", asRecord.Title.Trim()));
            sqlCmd.Parameters.Add(new SqlParameter("@DisplayArtistName", asRecord.DisplayArtistName.Trim()));

            sqlCmd.Parameters.Add(new SqlParameter("@ISWC", mwRecord.ISWC.Trim()));
            sqlCmd.Parameters.Add(new SqlParameter("@MusicWorkTitle", mwRecord.Title.Trim()));
            sqlCmd.Parameters.Add(new SqlParameter("@ComposerAuthor", mwRecord.ComposerAuthor.Trim()));

            sqlCmd.CommandText = "INSERT INTO DdexMusicWorkAuthors VALUES(@Id, @DdexReportId, @BlockId, @ISRC, @ResourceTitle, @DisplayArtistName, @ISWC, @MusicWorkTitle, @ComposerAuthor)";
            sqlCmd.Connection = sqlConn;
            try
            {
                sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                for (int i = 2; i < sqlCmd.Parameters.Count; i++)
                {
                    Logger.WriteLine($"{sqlCmd.Parameters[i].ParameterName} : {sqlCmd.Parameters[i].Value.ToString().Length}");
                }
                Logger.WriteLine(ex.Message);
            }

            /*string[] authorNames = mwRecord.fields[6].Split('|', '/');
            string[] authorPartyIds = mwRecord.fields[7].Split('|', '/');
            for (int i = 0; i < authorNames.Length; i++)
                InsertAuthor(mwId, authorNames[i], authorPartyIds.Length > i ? authorPartyIds[i] : "");*/
        }

        public void InsertAuthor(Guid ownerId, string authorName, string authorPartyId)
        {
            SqlCommand sqlCmd = new SqlCommand();

            Guid mwId = Guid.NewGuid();

            sqlCmd.Parameters.Add(new SqlParameter("@Id", mwId));
            sqlCmd.Parameters.Add(new SqlParameter("@DdexMusicWorkAuthorId", ownerId));
            sqlCmd.Parameters.Add(new SqlParameter("@Name", authorName));
            sqlCmd.Parameters.Add(new SqlParameter("@PartyId", authorPartyId));

            sqlCmd.CommandText = "INSERT INTO DdexMusicWorkAuthors VALUES(@Id, @DdexMusicWorkAuthorId, @Name, @PartyId)";
            sqlCmd.Connection = sqlConn;
            try
            {
                sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Logger.WriteLine($"{ex.Message} \"{authorName}\"");
            }
        }


        public void InsertInvoiceDetails(DdexReportBlock block)
        {
            bool hasSURecords = false;
            foreach (var suRecord in block.asRecord.mwRecords[0].suRecords)
            {
                hasSURecords = true;
                InsertInvoiceDetail(block, suRecord);
                if (!hasSURecords)
                    Logger.WriteLine("Block with no SURecords found");
            };
        }

        private void InsertInvoiceDetail(DdexReportBlock block, SURecord suRecord)
        {
            MWRecord mwRecord = block.asRecord.mwRecords[0];
            string summaryRecordId = suRecord.Fields[(int)SURecord.FieldIds.SummaryRecordId];
            SYRecord syRecord = block.report.GetSummaryRecord(summaryRecordId);

            SqlCommand sqlCmd = new SqlCommand();

            sqlCmd.Parameters.Add(new SqlParameter("@Id", Guid.NewGuid()));
            sqlCmd.Parameters.Add(new SqlParameter("@SequenceNumber", 1));
            sqlCmd.Parameters.Add(new SqlParameter("@CcidInvoiceId", Guid.Parse(invoiceId)));
            sqlCmd.Parameters.Add(new SqlParameter("@TRANSACTION_TYPE", "ORI"));
            sqlCmd.Parameters.Add(new SqlParameter("@REF_ID", "TBD"));
            sqlCmd.Parameters.Add(new SqlParameter("@CORRECTION_REFERENCE", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@SALES_TRANSACTION_ID", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@TRADING_BRAND", "?"));
            sqlCmd.Parameters.Add(new SqlParameter("@RELEASE_ID", suRecord.Fields[(int)SURecord.FieldIds.DspReleaseId]));
            sqlCmd.Parameters.Add(new SqlParameter("@RESOURCE_ID", block.asRecord.Fields[(int)ASRecord.FieldIds.DspResourceId]));
            sqlCmd.Parameters.Add(new SqlParameter("@ISRC", block.asRecord.Fields[(int)ASRecord.FieldIds.ISRC]));
            sqlCmd.Parameters.Add(new SqlParameter("@ISWC", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@WORKCODE", "PRC"));

            sqlCmd.Parameters.Add(new SqlParameter("@WORK_TITLE", mwRecord.Fields[(int)MWRecord.FieldIds.Title]));
            sqlCmd.Parameters.Add(new SqlParameter("@SERVICE_TYPE", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@USE_TYPE", ""));

            string usages = suRecord.Fields[(int)SURecord.FieldIds.Usages];
            //sqlCmd.Parameters.Add(new SqlParameter("@USE_QUANTITY", usages));
            sqlCmd.Parameters.Add(new SqlParameter("@USE_QUANTITY", "?"));

            sqlCmd.Parameters.Add(new SqlParameter("@APPLIED_TARIFF", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@ROYALTY_TYPE", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@PRICE_BASIS", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@ORIGINAL_PRICE_BASIS", "?"));
            sqlCmd.Parameters.Add(new SqlParameter("@ROYALTY", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@MUSIC_SHARE", "?"));
            sqlCmd.Parameters.Add(new SqlParameter("@RESTRICTIONS", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@FST_LICENSE", "?"));

            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_LICENSOR_COMBINED", "?"));

            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_PAI_COMBINED", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_UNMATCHED_COMBINED", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_PD_COMBINED", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_NOT_COLLECTED_COMBINED", ""));

            string amount = suRecord.Fields[(int)SURecord.FieldIds.NetRevenue];
            float floatAmount = float.Parse(amount, NumberStyles.Any, CultureInfo.GetCultureInfo("en-US"));
            if (floatAmount <= 0)
                return;
            int intAmount = ((int)Math.Round(floatAmount * 10000));
            sqlCmd.Parameters.Add(new SqlParameter("@AMOUNT_INVOICED_TOTAL", intAmount.ToString()));

            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_LICENSOR_MECH", "?"));
            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_LICENSOR_PERF", "?"));
            sqlCmd.Parameters.Add(new SqlParameter("@AMOUNT_LICENSOR_MECH", "?"));
            sqlCmd.Parameters.Add(new SqlParameter("@AMOUNT_LICENSOR_PERF", "?"));

            sqlCmd.Parameters.Add(new SqlParameter("@AMOUNT_PAI_MECH", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@AMOUNT_PAI_PERF", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@AMOUNT_PD_MECH", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@AMOUNT_PD_PERF", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@AMOUNT_NOT_COLLECTED_MECH", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@AMOUNT_NOT_COLLECTED_PERF", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@AMOUNT_UNMATCHED_MECH", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@AMOUNT_UNMATCHED_PERF", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_PAI_MECH", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_PAI_PERF", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_PD_MECH", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_PD_PERF", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_NOT_COLLECTED_MECH", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_NOT_COLLECTEDR_PERF", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_UNMATCHED_MECH", ""));
            sqlCmd.Parameters.Add(new SqlParameter("@CLAIM_UNMATCHED_PERF", ""));

            sqlCmd.Parameters.Add(new SqlParameter("@SourceBlockId", int.Parse(mwRecord.Fields[1])));
            int iii = 0;
            sqlCmd.Parameters.Add(new SqlParameter("@SourceMusicWorkIndex", iii));

            string rightType = syRecord.Fields[(int)SYRecord.FieldIds.RightsType];
            int rightTypeId = 0; //rightType.Equals("MechanicalRight") ? 1 : 2;
            sqlCmd.Parameters.Add(new SqlParameter("@RightType", rightTypeId));

            CheckSizes(sqlCmd.Parameters);

            sqlCmd.CommandText = sql;
            sqlCmd.Connection = sqlConn;
            try
            {
                sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Logger.WriteLine(ex.Message);
                int i = -1;
                foreach (var ci in colInfo)
                {
                    i++;
                    if (i < 3)
                        continue;
                    Logger.WriteLine($"Name = {ci.Name}, Size = {ci.Size}, ActualSize = {((string)sqlCmd.Parameters["@" + ci.Name].Value).Length}");
                }
                Logger.WriteLine(ex.Message);
            }
        }
    }
}
