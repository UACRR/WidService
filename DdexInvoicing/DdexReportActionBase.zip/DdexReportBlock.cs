﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YouTubeInvoicingConsole
{
    class DdexReportBlock
    {
        public bool isLast;
        public DdexReport report;
        public ASRecord asRecord = new ASRecord();

        public DdexReportBlock(DdexReport report)
        {
            this.report = report;
        }

        public bool IsFinalMusicWork(MWRecord mwRecord)
        {
            return mwRecord.ruRecords.Count == 0 && mwRecord.suRecords.Count == 0 && mwRecord.liRecords.Count == 0;
        }
        private void UpdateStatistics(DdexReport report)
        {
            report.maxCountMW = report.maxCountMW < asRecord.mwRecords.Count ? asRecord.mwRecords.Count : report.maxCountMW;
            foreach (var mwRecord in asRecord.mwRecords)
            {
                if (IsFinalMusicWork(mwRecord))
                    continue;

                if (mwRecord.ruRecords.Count == 0)
                    report.missingRU = true;
                if (mwRecord.suRecords.Count == 0)
                    report.missingSU = true;
                if (mwRecord.liRecords.Count == 0)
                    report.missingLI = true;

                report.maxCountRU = report.maxCountRU < mwRecord.ruRecords.Count ? mwRecord.ruRecords.Count : report.maxCountRU;
                report.maxCountSU = report.maxCountSU < mwRecord.suRecords.Count ? mwRecord.suRecords.Count : report.maxCountSU;
                report.maxCountLI = report.maxCountLI < mwRecord.liRecords.Count ? mwRecord.liRecords.Count : report.maxCountLI;
            }
        }

        public void Init(StreamReader streamReader, ref string firstLine)
        {
            // CORRECT ERROR IN FILE
            CorrectLine(ref firstLine, 0);
            //======================
            string[] fields = firstLine.Split('\t');
            string blockId = fields[1];
            if(int.Parse(blockId) % 10000 == 0)
                Logger.WriteLine($"Processing blocks - last processed {blockId}");
            MWRecord mwRecord = new MWRecord();

            var nextLine = firstLine;
            
            int lineIndex = 1;
            while ((!streamReader.EndOfStream && !fields[0].Equals("FOOT") && fields[1].Equals(blockId)))
            {
                string recordType = fields[0];
                if (recordType.Equals("AS01.01"))
                {
                    asRecord.Fields = fields;
                }
                else if (recordType.Equals("MW01.01"))
                {
                    mwRecord = new MWRecord();
                    mwRecord.Fields = fields;
                    asRecord.mwRecords.Add(mwRecord);
                    lineIndex++;
                }
                else if (recordType.Equals("RU01.01"))
                {
                    RURecord record = new RURecord();
                    record.Fields = fields;
                    mwRecord.ruRecords.Add(record);
                }
                else if (recordType.Equals("SU03.02"))
                {
                    SURecord record = new SURecord();
                    record.Fields = fields;
                    mwRecord.suRecords.Add(record);
                }
                else if (recordType.Equals("LI01.02"))
                {
                    LIRecord record = new LIRecord();
                    record.Fields = fields;
                    mwRecord.liRecords.Add(record);
                }

                nextLine = streamReader.ReadLine();
                // CORRECT ERROR IN FILE
                CorrectLine(ref nextLine, lineIndex);
                //======================
                fields = nextLine.Split('\t');
            }

            firstLine = nextLine;

            isLast = fields[0].Equals("FOOT");
        }

        private void CorrectLine(ref string line, int recordIndex)
        {
            string[] fields = line.Split('\t');
            string key = $"{fields[1]}-{fields[0]}";
            if(report.recordsToCorrect.Contains(key))
            {
                line = line.Replace("\\\t", ",");
            }
        }

        public bool Process(DdexReportActionBase action, StreamReader streamReader, ref string firstLine)
        {
            UpdateStatistics(report);
            action.ProcessBlock(this);
            return !isLast;
        }
    }

}
