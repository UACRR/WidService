﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YouTubeInvoicingConsole
{
    class DdexReportActionCalcStatistics : DdexReportActionBase
    {
        private DdexReport report;

        public DdexReportActionCalcStatistics(DdexReport report)
        {
            this.report = report;
        }

        private void UpdateFieldLengths(DdexRecordBase record)
        {
            DdexStatistics statistics = report.statistics;
            if (!statistics.maxColLengths.ContainsKey(record.RecordId))
            {
                int[] fieldLengths = new int[record.Fields.Length];
                string[] colValues = new string[record.Fields.Length];
                for (int i = 0; i < fieldLengths.Length; i++)
                {
                    fieldLengths[i] = 0;
                }
                statistics.maxColLengths.Add(record.RecordId, fieldLengths);
                statistics.longestColValues.Add(record.RecordId, colValues);
            }
            int[] curFieldLengths = statistics.maxColLengths[record.RecordId];
            string[] curFieldValues = statistics.longestColValues[record.RecordId];
            for (int i = 0; i < curFieldLengths.Length; i++)
            {
                if(curFieldLengths[i] < record.Fields[i].Length)
                {
                    curFieldLengths[i] = record.Fields[i].Length;
                    curFieldValues[i] = record.Fields[i];
                }
             }
        }

        public override void ProcessHead(HEADRecord record)
        {
            UpdateFieldLengths(record);
        }

        public override void ProcessFoot(FOOTRecord record)
        {
            UpdateFieldLengths(record);
            ValidateColSizes();
        }

        public override void ProcessSY(SYRecord record)
        {
            UpdateFieldLengths(record);
        }

        public override void ProcessBlock(DdexReportBlock block)
        {
            UpdateFieldLengths(block.asRecord);
            foreach (var mwRecord in block.asRecord.mwRecords)
            {
                UpdateFieldLengths(mwRecord);
                foreach(var suRecord in mwRecord.suRecords)
                {
                    UpdateFieldLengths(suRecord);
                }
                foreach (var ruRecord in mwRecord.ruRecords)
                {
                    UpdateFieldLengths(ruRecord);
                }
                foreach (var liRecord in mwRecord.liRecords)
                {
                    UpdateFieldLengths(liRecord);
                }
            }
        }

        private void ValidateColSizes()
        {
            DdexStatistics statistics = report.statistics;
            using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]))
            {   try
                {
                    sqlConn.Open();
                }
                catch (Exception ex)
                {
                    Logger.WriteLine(ex.Message);
                }

                foreach (var pair in statistics.maxColLengths)
                {
                    string recordType = pair.Key;
                    var requiredColLengths = pair.Value;
                    SqlCommand sqlCmd = new SqlCommand();
                    sqlCmd.CommandText = @"SELECT COLUMN_NAME, CHARACTER_MAXIMUM_LENGTH, DATA_TYPE
                        FROM INFORMATION_SCHEMA.COLUMNS
                        WHERE TABLE_NAME = @TableName
                        ORDER BY ORDINAL_POSITION";
                    sqlCmd.Parameters.Add(new SqlParameter("@TableName", recordType.Replace('.', '_')));
                    sqlCmd.Connection = sqlConn;
                    DataTable dtColInfo = new DataTable();
                    using (SqlDataAdapter da = new SqlDataAdapter(sqlCmd))
                    {
                        try
                        {
                            da.Fill(dtColInfo);
                        }
                        catch (Exception ex)
                        {
                            Logger.WriteLine(ex.Message);
                        }
                    }

                    int i = recordType.Equals("MW01.01") || recordType.Equals("RU01.01") || recordType.Equals("SU03.02") || recordType.Equals("LI01.02") ? 2 : 1;
                    int fieldIndex = 1;
                    for(; fieldIndex < requiredColLengths.Length; i++, fieldIndex++)
                    {
                        DataRow colInfo = dtColInfo.Rows[i];
                        string colName = (string)colInfo[0];
                        int colSize = colInfo[1] == DBNull.Value ? 0 : (int)colInfo[1];
                        string colType = (string)colInfo[2];
                        string fieldValue = statistics.longestColValues[recordType][fieldIndex];
                        int requiredColLength = requiredColLengths[fieldIndex];
                        if (colType.Equals("nvarchar") && colSize < requiredColLength)
                        {
                            Logger.WriteLine($@"Size of column {recordType.Replace('.', '_')}.{colName} should be increased from {colSize} to {requiredColLength} due to value {fieldValue}");
                        }
                    }
                }
            }
        }

    }
}
