﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YouTubeInvoicingConsole
{
    class DdexReportActionFillMusicWorkAuthors : DdexReportActionBase
    {
        private DdexReport report;
        private SqlConnection sqlConn;
        public int recordCount = 0;
        private int lastProcessedBlockId;

        BulkUploadToSql bulkUploader;

        public DdexReportActionFillMusicWorkAuthors()
        {
        }

        public override void Init(DdexReport report)
        {
            this.report = report;
            try
            {
                sqlConn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
                sqlConn.Open();
            }
            catch (Exception ex)
            {
                Logger.WriteLine(ex.Message);
            }

            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandText = @"DECLARE @lastBlockId int;
                        SELECT @lastBlockId = MAX(CAST(BlockId AS int)) FROM DdexMusicWorkAuthors WHERE DdexReportId = @DdexReportId;
                        DELETE FROM DdexMusicWorkAuthors WHERE DdexReportId = @DdexReportId and BlockId = @lastBlockId; 
                        SELECT @lastBlockId";
            sqlCmd.Parameters.Add(new SqlParameter("@DdexReportId", report.ddexReportId));
            sqlCmd.Connection = sqlConn;
            try
            {
                object lastProcessed = sqlCmd.ExecuteScalar();
                lastProcessedBlockId = lastProcessed == null ? 0 : int.Parse(lastProcessed.ToString());
            }
            catch (Exception ex)
            {
                Logger.WriteLine(ex.Message);
            }

            bulkUploader = new BulkUploadToSql();
            bulkUploader.TableName = "DdexMusicWorkAuthors";
            bulkUploader.sqlConn = sqlConn;
        }

        public override int GetLastProcessedBlockId()
        {
            return lastProcessedBlockId;
        }

        public override void ProcessFoot(FOOTRecord footRecord)
        {
            bulkUploader.Flush();
        }

        public override void ProcessBlock(DdexReportBlock block)
        {
            InsertMusicWorks(block);
        }

        public void InsertMusicWorks(DdexReportBlock block)
        {
            Dictionary<string, MWRecord> recordsWithISWC = new Dictionary<string, MWRecord>();
            foreach (var mwRecord in block.asRecord.mwRecords)
            {
                foreach (var suRecord in mwRecord.suRecords)
                {
                    if (suRecord.SummaryRecordId.Equals("11"))
                    {
                        float usages = float.Parse(suRecord.Usages, NumberStyles.Any, CultureInfo.GetCultureInfo("en-US"));
                        block.report.usagesFromSU += usages;
                    }
                }
                foreach (var ruRecord in mwRecord.ruRecords)
                {
                    if (ruRecord.SummaryRecordId.Equals("11") && !string.IsNullOrEmpty(ruRecord.Usages.Trim()))
                    {
                        string[] usages = ruRecord.Usages.Split('|');
                        foreach (var usage in usages)
                        {
                            float floatUsage = float.Parse(usage, NumberStyles.Any, CultureInfo.GetCultureInfo("en-US"));
                            block.report.usagesFromRU += floatUsage;
                        }

                    }
                }

                if (!string.IsNullOrEmpty(mwRecord.ISWC.Trim()) && !recordsWithISWC.ContainsKey(mwRecord.ISWC))
                    recordsWithISWC.Add(mwRecord.ISWC, mwRecord);
            };

            foreach (var mwRecord in block.asRecord.mwRecords)
            {
                if (recordsWithISWC.ContainsKey(mwRecord.ISWC))
                {
                    var mwRecordWithISWC = recordsWithISWC[mwRecord.ISWC];
                    if (mwRecordWithISWC.Title.Equals(mwRecord.Title, StringComparison.OrdinalIgnoreCase))
                        mwRecord.ISWC = mwRecordWithISWC.ISWC;
                }
            };

            List<MWRecord> targetRecords = new List<MWRecord>();
            Dictionary<string, int> processedISWCs = new Dictionary<string, int>();
            foreach (var mwRecord in block.asRecord.mwRecords)
            {
                if (string.IsNullOrEmpty(mwRecord.ISWC))
                    continue;
                if (!processedISWCs.ContainsKey(mwRecord.ISWC) && !string.IsNullOrEmpty(mwRecord.ComposerAuthor.Trim()))
                {
                    targetRecords.Add(mwRecord);
                    processedISWCs.Add(mwRecord.ISWC, 0);
                }
            };

            Dictionary<string, int> processedTitles = new Dictionary<string, int>();
            foreach (var mwRecord in block.asRecord.mwRecords)
            {
                if (!string.IsNullOrEmpty(mwRecord.ISWC))
                    continue;
                if (!processedTitles.ContainsKey(mwRecord.Title) && !string.IsNullOrEmpty(mwRecord.ComposerAuthor.Trim()))
                {
                    targetRecords.Add(mwRecord);
                    processedTitles.Add(mwRecord.Title, 0);
                }
            };

            foreach (var mwRecord in targetRecords)
                InsertMusicWork(block.report.ddexReportId, block.asRecord, mwRecord);
        }

        public void InsertMusicWork(int ddexReportId, ASRecord asRecord, MWRecord mwRecord)
        {
            int zero = 0;
            DdexMusicWorkAuthor ddexMusicWorkAuthor = new DdexMusicWorkAuthor
            {
                Id = null,
                DdexReportId = ddexReportId,
                BlockId = mwRecord.BlockId,

                ISRC = asRecord.ISRC.Trim(),
                ResourceTitle = asRecord.Title.Trim(),
                DisplayArtistName = asRecord.DisplayArtistName.Trim(),

                ISWC = mwRecord.ISWC.Trim(),
                MusicWorkTitle = mwRecord.Title.Trim(),
                ComposerAuthor = mwRecord.ComposerAuthor.Trim(),

                WidCode = zero,
                ObjId = zero,
            };

            var data = new List<object>();
            data.Add(null);
            data.Add(ddexReportId);
            data.Add(mwRecord.BlockId);

            data.Add(asRecord.ISRC.Trim());
            data.Add(asRecord.Title.Trim());
            data.Add(asRecord.DisplayArtistName.Trim());

            data.Add(mwRecord.ISWC.Trim());
            data.Add(mwRecord.Title.Trim());
            data.Add(mwRecord.ComposerAuthor.Trim());

            data.Add(zero);
            data.Add(zero);
            //bulkUploader.AddData(ddexMusicWorkAuthor);
            bulkUploader.AddData(data);

            try
            {
                //sqlCmd.ExecuteNonQuery();
                //sqlCmd.ExecuteNonQueryAsync();
                recordCount++;
            }
            catch (Exception ex)
            {
                //for (int i = 2; i < sqlCmd.Parameters.Count; i++)
                //{
                    //Logger.WriteLine($"{sqlCmd.Parameters[i].ParameterName} : {sqlCmd.Parameters[i].Value.ToString().Length}");
                //}
                //Logger.WriteLine(ex.Message);
            }

            /*string[] authorNames = mwRecord.fields[6].Split('|', '/');
            string[] authorPartyIds = mwRecord.fields[7].Split('|', '/');
            for (int i = 0; i < authorNames.Length; i++)
                InsertAuthor(mwId, authorNames[i], authorPartyIds.Length > i ? authorPartyIds[i] : "");*/
        }
    }

}
