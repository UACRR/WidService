﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YouTubeInvoicingConsole
{
    static class Logger
    {
        //public static TextBox tb;
        public static BackgroundWorker bw;
        //public static string msgText;
        public static ConcurrentQueue<string> messages = new ConcurrentQueue<string>();

        public static void Reset()
        {
        }

        public static void WriteLine(string text)
        {
            Console.WriteLine(text);

            messages.Enqueue($"{DateTime.Now.ToString()}: {text}\r\n");
            bw.ReportProgress(0);
        }

        public static void Write(string text)
        {
            Console.WriteLine(text);

            messages.Enqueue($"{DateTime.Now.ToString()}: {text}");
            bw.ReportProgress(0);
        }
    }
}
