﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YouTubeInvoicingConsole
{
    class DdexReportActionValidate : DdexReportActionBase
    {
        private DdexReport report;
        private SqlConnection sqlConn;
        BulkUploadToSql bulkUploader;

        public DdexReportActionValidate()
        {

        }

        public override void Init(DdexReport report)
        {
            this.report = report;
            try
            {
                sqlConn = new SqlConnection(ConfigurationManager.AppSettings["ConnectionString"]);
                sqlConn.Open();
            }
            catch (Exception ex)
            {
                Logger.WriteLine(ex.Message);
            }

            bulkUploader = new BulkUploadToSql
            {
                TableName = "DdexFileErrors",
                sqlConn = sqlConn
            };
        }

        private void ValidateRecord(DdexRecordBase record, string tableName, int recordIndex)
        {
            try
            {
                int expectedFieldsCount = record.GetFieldCount();
                int actualFieldsCount = record.Fields.Length;
                if (expectedFieldsCount != actualFieldsCount)
                {
                    string errorText = $"Error in record {record.Fields[0]} - actual fields count ({actualFieldsCount}) is not like expected ({expectedFieldsCount})";
                    string recordText = "";
                    string sep = "";
                    foreach(var field in record.Fields)
                    {
                        recordText += sep + field;
                        sep = "{TAB}";
                    }
                    Logger.WriteLine(errorText);
                    Logger.WriteLine(recordText);
                    var data = new List<object>();
                    data.Add(null);
                    data.Add(report.ddexReportId);
                    data.Add(record.IsBlockRecord() ? record.Fields[1] : "");
                    data.Add(record.Fields[0]);
                    data.Add(recordIndex);
                    data.Add(errorText);
                    data.Add(recordText);
                    bulkUploader.AddData(data);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLine($"Error in table {tableName}, {ex.Message}");
                Logger.WriteLine($"   Wrong format of record");
                record.Dump(record.Fields);
            }
        }

        public override void ProcessHead(HEADRecord record)
        {
            ValidateRecord(record, "HEAD", 0);
        }

        public override void ProcessFoot(FOOTRecord record)
        {
            ValidateRecord(record, "FOOT", 0);
            bulkUploader.Flush();
        }

        public override void ProcessSY(SYRecord record)
        {
            ValidateRecord(record, "SY02_02", 0);
        }

        public override void ProcessBlock(DdexReportBlock block)
        {
            try
            {
                int asRecordIndex = 0;
                int mwRecordIndex = 0;
                ValidateRecord(block.asRecord, "AS01_01", asRecordIndex++);
                foreach (var mwRecord in block.asRecord.mwRecords)
                {
                    ValidateRecord(mwRecord, "MW01_01", mwRecordIndex++);
                    int liRecordIndex = 0;
                    int suRecordIndex = 0;
                    int ruRecordIndex = 0;
                    foreach (var liRecord in mwRecord.liRecords)
                    {
                        ValidateRecord(liRecord, "LI01_02", liRecordIndex++);
                    }
                    foreach (var suRecord in mwRecord.suRecords)
                    {
                        ValidateRecord(suRecord, "SU03_02", suRecordIndex++);
                    }
                    foreach (var ruRecord in mwRecord.ruRecords)
                    {
                        ValidateRecord(ruRecord, "RU01_01", ruRecordIndex++);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLine(ex.Message);
            }
        }
    }
}
