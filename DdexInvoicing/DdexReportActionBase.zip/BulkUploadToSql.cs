﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace YouTubeInvoicingConsole
{
    public class BulkUploadToSql
    {
        public string TableName { get; set; }
        public int CommitBatchSize { get; set; } = 10000;
        public SqlConnection sqlConn { get; set; }
        public DataTable dtColInfo { get; set; }

        private DataTable dt;
        private SqlBulkCopy bulkCopy;

        private void Init()
        {
            if (bulkCopy == null)
                bulkCopy = new SqlBulkCopy(
                    sqlConn,
                    SqlBulkCopyOptions.TableLock | SqlBulkCopyOptions.FireTriggers | SqlBulkCopyOptions.UseInternalTransaction,
                    null
                );

            if (dtColInfo == null)
            {
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandText = @"SELECT COLUMN_NAME, CHARACTER_MAXIMUM_LENGTH
                        FROM INFORMATION_SCHEMA.COLUMNS
                        WHERE TABLE_NAME = @TableName
                        ORDER BY ORDINAL_POSITION";
                sqlCmd.Parameters.Add(new SqlParameter("@TableName", TableName));
                sqlCmd.Connection = sqlConn;
                using (SqlDataAdapter da = new SqlDataAdapter(sqlCmd))
                {
                    try
                    {
                        dtColInfo = new DataTable();
                        da.Fill(dtColInfo);
                    }
                    catch (Exception ex)
                    {
                        Logger.WriteLine(ex.Message);
                    }
                }
            }

            if (dt == null)
            {

                dt = new DataTable();
                foreach (DataRow colInfo in dtColInfo.Rows)
                {
                    string colType = colInfo[1].ToString();
                    dt.Columns.Add((string)colInfo[0], colType.Equals("int") ? typeof(int)
                        : colType.Equals("date") ? typeof(DateTime)
                        : colType.Equals("decimal") ? typeof(decimal)
                        : typeof(string));
                }
            }
        }

        public void AddData(List<object> data)
        {
            Init();

            DataRow row = dt.NewRow();
            bool hasErrors = false;
            int colInfoRowIndex = 0;
            foreach (var propValue in data)
            {
                row[colInfoRowIndex] = propValue;
                colInfoRowIndex++;
            }

            if (hasErrors)
                return;

            dt.Rows.Add(row);

            if (dt.Rows.Count == CommitBatchSize)
            {
                Flush();
            }

        }

        public DataTable GetColInfo()
        {
            Init();
            return dtColInfo;
        }

        public void Flush()
        {
            if (dt == null) // no rows inserted
                return;
            BulkInsert(dt);
            dt.Rows.Clear();
        }

        private void BulkInsert(DataTable dt)
        {
            try
            {
                SqlBulkCopy bulkCopy = new SqlBulkCopy(
                    sqlConn,
                    SqlBulkCopyOptions.TableLock | SqlBulkCopyOptions.FireTriggers | SqlBulkCopyOptions.UseInternalTransaction,
                    null
                );

                bulkCopy.DestinationTableName = TableName;
                bulkCopy.WriteToServer(dt);
            }
            catch(Exception ex)
            {
                Logger.WriteLine(ex.Message);
            }
        }

    }
}
