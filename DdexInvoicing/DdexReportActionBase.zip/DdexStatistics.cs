﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YouTubeInvoicingConsole
{
    class DdexStatistics
    {
        public Dictionary<string, int[]> maxColLengths = new Dictionary<string, int[]>();
        public Dictionary<string, string[]> longestColValues = new Dictionary<string, string[]>();
    }
}
