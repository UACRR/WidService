﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YouTubeInvoicingConsole
{
    class HEADRecord : DdexRecordBase
    {
        enum FieldIds
        {
            MessageVersion = 1
            , Profile
            , ProfileVersion
            , MessageId
            , MessageCreatedDateTime
            , FileNumber
            , NumberofFiles
            , UsageStartDate
            , UsageEndDate
            , SenderPartyId
            , SenderName
            , ServiceDescription
            , RecipientPartyId
            , RecipientName
            , RepresentedRepertoire
        }

        public override object ConvertField(int fieldIndex) {
            switch(fieldIndex)
            {
                case 0: case 1:
                    return Fields[fieldIndex];
                default:
                    return Fields[fieldIndex];
            }
        }

        public override int GetFieldCount() { return 16; }
    }

    class FOOTRecord : DdexRecordBase
    {
        enum FieldIds
        {
            NumberOfLinesInFile = 1
            , NumberOfLinesInReport
            , NumberOfSummaryRecords
            , NumberOfBlocksInFile
            , NumberOfBlocksInReport
        }

        public override object ConvertField(int fieldIndex)
        {
            return int.Parse(Fields[fieldIndex]);
        }

        public override int GetFieldCount() { return 6; }
    }

    class SYRecord : DdexRecordBase
    {
        public enum FieldIds
        {
            SummaryRecordId = 1
            , DistributionChannel
            , DistributionChannelDPID
            , CommercialModel
            , UseType
            , Territory
            , ServiceDescription
            , Usages
            , Users
            , Currency
            , NetRevenue
            , RightsController
            , RightsControllerPartyId
            , AllocatedUsages
            , AllocatedRevenue
            , AllocatedNetRevenue
            , RightsType
            , ContentCategory
            , ExchangeRateBaseCurrency
            , ExchangeRate
            , RightsTypePercentage
       }

        public float TotalSumPercentFromMW = 0;

        public override object ConvertField(int fieldIndex)
        {
            try
            {
                switch (fieldIndex)
                {
                    case (int)FieldIds.Usages:
                    case (int)FieldIds.Users:
                        return string.IsNullOrEmpty(Fields[fieldIndex].Trim()) ? 0 : int.Parse(Fields[fieldIndex]);
                    case (int)FieldIds.NetRevenue:
                    case (int)FieldIds.AllocatedNetRevenue:
                    case (int)FieldIds.ExchangeRate:
                    case (int)FieldIds.RightsTypePercentage:
                        return string.IsNullOrEmpty(Fields[fieldIndex].Trim()) ? 0 : decimal.Parse(Fields[fieldIndex], NumberStyles.Any, CultureInfo.GetCultureInfo("en-US"));
                    default:
                        return Fields[fieldIndex];
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public override int GetFieldCount() { return 22; }
    }

    class ASRecord : DdexRecordBase
    {
        public enum FieldIds
        {
            BlockId = 1
            , ResourceReference
            , DspResourceId
            , ISRC
            , Title
            , SubTitle
            , DisplayArtistName
            , DisplayArtistPartyId
            , Duration
            , ResourceType
            , IsMasterRecording
        }

        public string BlockId { get { return Fields[(int)FieldIds.BlockId]; } set { Fields[(int)FieldIds.BlockId] = value; } }
        public string ISRC { get { return Fields[(int)FieldIds.ISRC]; } set { Fields[(int)FieldIds.ISRC] = value; } }
        public string Title { get { return Fields[(int)FieldIds.Title]; } set { Fields[(int)FieldIds.Title] = value; } }
        public string DisplayArtistName { get { return Fields[(int)FieldIds.DisplayArtistName]; } set { Fields[(int)FieldIds.DisplayArtistName] = value; } }

        public List<MWRecord> mwRecords = new List<MWRecord>();

        public override int GetFieldCount() { return 12; }
        public override bool IsBlockRecord() { return true; }
    }

    class MWRecord : DdexRecordBase
    {
        public enum FieldIds
        {
            BlockId = 1
            , DspWorkId
            , ISWC
            , Title
            , SubTitle
            , ComposerAuthor
            , ComposerAuthorPartyId
            , Arranger
            , ArrangerPartyId
            , MusicPublisher
            , MusicPublisherPartyId
            , WorkContributor
            , WorkContributorPartyId
            , DataProvider
            , ProprietaryWorkId

            , SummaryRecordId
            , RightsController
            , RightsControllerPartyId
            , RightsControllerWorkID
            , RightSharePercent
            , RightType
            , AllocatedNetRevenue
            , AllocatedAmount
            , AllocatedUsages
        }

        public string BlockId { get { return Fields[(int)FieldIds.BlockId]; } set { Fields[(int)FieldIds.BlockId] = value; } }
        public string ISWC { get { return Fields[(int)FieldIds.ISWC]; } set { Fields[(int)FieldIds.ISWC] = value; } }
        public string Title { get { return Fields[(int)FieldIds.Title]; } set { Fields[(int)FieldIds.Title] = value; } }
        public string ComposerAuthor { get { return Fields[(int)FieldIds.ComposerAuthor]; } set { Fields[(int)FieldIds.ComposerAuthor] = value; } }
        public string ComposerAuthorPartyId { get { return Fields[(int)FieldIds.ComposerAuthorPartyId]; } set { Fields[(int)FieldIds.ComposerAuthorPartyId] = value; } }

        public List<RURecord> ruRecords = new List<RURecord>();
        public List<SURecord> suRecords = new List<SURecord>();
        public List<LIRecord> liRecords = new List<LIRecord>();

        public override object ConvertField(int fieldIndex)
        {
            try
            {
                switch (fieldIndex)
                {
                    case (int)FieldIds.RightSharePercent:
                    case (int)FieldIds.AllocatedNetRevenue:
                    case (int)FieldIds.AllocatedAmount:
                    case (int)FieldIds.AllocatedUsages:
                        return string.IsNullOrEmpty(Fields[fieldIndex].Trim()) ? 0 : decimal.Parse(Fields[fieldIndex], NumberStyles.Any, CultureInfo.GetCultureInfo("en-US"));
                    default:
                        return Fields[fieldIndex];
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public override int GetFieldCount() { return 16; }
        public override bool IsBlockRecord() { return true; }
    }

    class RURecord : DdexRecordBase
    {
        public enum FieldIds
        {
            BlockId = 1
            , SummaryRecordId
            , DspReleaseId
            , Usages
            , ContentCategory
        }

        public string BlockId { get { return Fields[(int)FieldIds.BlockId]; } set { Fields[(int)FieldIds.BlockId] = value; } }
        public string SummaryRecordId { get { return Fields[(int)FieldIds.SummaryRecordId]; } set { Fields[(int)FieldIds.SummaryRecordId] = value; } }
        public string Usages { get { return Fields[(int)FieldIds.Usages]; } set { Fields[(int)FieldIds.Usages] = value; } }
        public string ContentCategory { get { return Fields[(int)FieldIds.ContentCategory]; } set { Fields[(int)FieldIds.ContentCategory] = value; } }

        public override int GetFieldCount() { return 6; }
        public override bool IsBlockRecord() { return true; }
    }

    class SURecord : DdexRecordBase
    {
        public enum FieldIds
        {
            BlockId = 1
            , SalesTransactionId
            , SummaryRecordId
            , DspReleaseId
            , Usages
            , NetRevenue
            , ValidityPeriodStart
            , ValidityPeriodEnd
            , ContentCategory
            , IsRoyaltyBearing
        }

        public string SummaryRecordId { get { return Fields[(int)FieldIds.SummaryRecordId]; } set { Fields[(int)FieldIds.SummaryRecordId] = value; } }
        public string Usages { get { return Fields[(int)FieldIds.Usages]; } set { Fields[(int)FieldIds.Usages] = value; } }

        public override object ConvertField(int fieldIndex)
        {
            try
            {
                switch (fieldIndex)
                {
                    case (int)FieldIds.Usages:
                    case (int)FieldIds.NetRevenue:
                        return string.IsNullOrEmpty(Fields[fieldIndex].Trim()) ? 0 : decimal.Parse(Fields[fieldIndex], NumberStyles.Any, CultureInfo.GetCultureInfo("en-US"));
                    case (int)FieldIds.ValidityPeriodStart:
                    case (int)FieldIds.ValidityPeriodEnd:
                        string[] dateParts = Fields[fieldIndex].Split('-');
                        return new DateTime(int.Parse(dateParts[0]), int.Parse(dateParts[1]), int.Parse(dateParts[2]));
                    default:
                        return Fields[fieldIndex];
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public override int GetFieldCount() { return 11; }
        public override bool IsBlockRecord() { return true; }
    }

    class LIRecord : DdexRecordBase
    {
        public enum FieldIds
        {
            BlockId = 1
            , SummaryRecordId
            , RightsController
            , RightsControllerPartyId
            , RightsControllerWorkID
            , RightSharePercent
            , RightType
            , AllocatedNetRevenue
            , AllocatedAmount
            , AllocatedUsages
        }

        public string RightSharePercent { get { return Fields[(int)FieldIds.RightSharePercent]; } set { Fields[(int)FieldIds.RightSharePercent] = value; } }
        public override int GetFieldCount() { return 11; }
        public override bool IsBlockRecord() { return true; }
    }

    class DdexRecordBase
    {
        public string[] fields;

        public string[] Fields {
            get { return fields; }
            set
            {
                /*if(value.Length != GetFieldCount())
                {
                    Logger.WriteLine($"Invalid fields count in record {value[0]}");
                    Dump(value);
                }*/
                fields = value;
            }
        }

        public string RecordId { get { return fields[0]; } set { fields[0] = value; } }

        public virtual object ConvertField(int fieldIndex) { return fields[fieldIndex]; }
        public virtual int GetFieldCount() { return 0; }
        public virtual bool IsBlockRecord() { return false; }

        public void Dump(string[] fields)
        {
            Logger.WriteLine("============================================");
            int i = 1;
            foreach (var field in fields)
                Logger.WriteLine("Line" + i++ + ": " + field);
            Logger.WriteLine("============================================");
        }
    }

}
