﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YouTubeInvoicingConsole
{
    class DdexReportActionBase
    {
        public virtual void Init(DdexReport report) { }
        public virtual int GetLastProcessedBlockId() { return 0; }
        public virtual void ProcessBlock(DdexReportBlock block) { }
        public virtual void ProcessHead(HEADRecord readRecord) { }
        public virtual void ProcessFoot(FOOTRecord footRecord) { }
        public virtual void ProcessSY(SYRecord syRecord) { }
    }
}
